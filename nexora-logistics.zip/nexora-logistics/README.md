# NEXORA LOGISTICS — LOGISTICS NETWORK

Responsive shipment-tracking web application starter built with HTML/CSS/JavaScript, Supabase Auth + PostgreSQL/RLS, Leaflet/OpenStreetMap, and OSRM road routing.

## What is implemented

- Responsive public homepage, services/about/contact sections, privacy and terms pages.
- Supabase customer registration, email/password login, session persistence, and logout.
- The database trigger grants the `admin` role only to the exact allowlisted email `nosadpe@gmail.com`; all other signups are customers.
- Customer dashboard queries only shipments assigned to the signed-in user's profile (RLS enforced).
- Public tracking RPC returns a restricted projection: no sender/recipient names, phone numbers, destination street address, customer ID/email, admin actor, or arbitrary event JSON.
- Private admin dashboard, database-backed shipment counts, shipment creation/editing, customer assignment by registered email, server-generated unique tracking numbers, status/transport/date/coordinate fields, and company contact settings.
- Database audit trigger writes append-only history events for shipment creation, status changes, current-location changes, transport changes, and route changes.
- Leaflet interactive map with saved origin/destination/current markers. Current location marker is red and is never simulated.
- Land route lookup via OSRM; Air Freight uses a clearly labelled illustrative direct corridor; Sea Freight uses a clearly labelled approximate corridor (not a verified sea lane).
- Invalid tracking number, missing updates, map errors, loading states, and form errors are handled in the UI.

## Important limitations (do not represent these as completed features)

1. **No live GPS or live aircraft/ship tracking.** Current shipment position is only the last coordinate manually saved by an administrator.
2. **Sea Freight routing is approximate.** A maritime routing dataset/service and port geocoding must be integrated before claiming a navigable sea-lane route. The dashed map line is explicitly labelled approximate.
3. **Air Freight route is illustrative only.** It is not a flight plan and does not include flight tracking.
4. **OSRM public demo endpoint and OpenStreetMap public tiles are community services, not a production SLA.** For commercial traffic, configure a hosted routing provider and tile provider, observing their terms and rate limits.
5. **No proof-of-delivery upload/signature workflow yet.** Delivery can be marked Delivered by the administrator; secure photo/signature storage still needs a private Storage bucket and upload workflow.
6. **No durable API rate limiter/contact-form ticket storage yet.** The contact form opens the visitor's email application and requires a configured company email. Before public production, place public tracking behind a rate-limited Edge Function/API gateway and add CAPTCHA/abuse protection as appropriate.
7. **No browser/device farm test was possible here.** JavaScript syntax is checked, but live Supabase credentials, real account registration, RLS behavior, deployed routing, and iPhone/Android behavior must be verified after setup.

## 1. Create and configure Supabase

1. Create a Supabase project at <https://supabase.com>.
2. Open **SQL Editor** in the project.
3. Run the complete contents of `supabase/schema.sql` once.
4. In **Project Settings → API**, copy the Project URL and the public anon/publishable key.
5. Open `config.js` and replace `YOUR-PROJECT` and `YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY`.
6. It is safe for the browser to receive the Supabase **anon/publishable** key only because access is controlled by RLS and database functions. **Never put the `service_role` key in this repository or any browser file.**
7. In **Authentication → URL Configuration**, set your deployed site URL and add your local development URL (for example `http://localhost:5500`) to the allowed redirect URLs.
8. In **Authentication → Providers → Email**, keep email/password enabled. Email confirmation is recommended for production.

### Create the administrator

1. In the website, register using exactly `nosadpe@gmail.com` and a strong password.
2. Confirm that email using the message Supabase sends.
3. Sign in with that account. The database signup trigger assigns the admin role only when the verified signup email matches the allowlisted email.
4. All other registered accounts receive the `customer` role. The client does not submit a role field.

The initial administrator does not exist until this signup is completed. Do not share the admin password. Protect the mailbox with MFA and a strong unique password.

## 2. Run locally

From this directory, start any static web server. For example, with Python installed:

```bash
python -m http.server 5500
```

Open <http://localhost:5500>. Do not open `index.html` as a `file://` URL because browser module/network/auth behavior is more reliable over HTTP.

## 3. Publish with GitHub Pages

1. Upload the contents of this folder (not the containing folder) to the root of your GitHub repository.
2. Confirm `index.html`, `styles.css`, `app.js`, `config.js`, `privacy.html`, `terms.html`, and `supabase/schema.sql` are present.
3. Commit and push the files.
4. In GitHub repository **Settings → Pages**, select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish, then copy the generated website URL into Supabase **Authentication → URL Configuration → Site URL** and allowed redirect URLs.

GitHub Pages hosts only the static frontend. Supabase is the separate hosted backend/database/authentication service.

## 4. Admin workflow

- Register customers before assigning shipments to them.
- Sign in with the allowlisted admin account.
- In the admin dashboard choose **New shipment**.
- Optionally enter the registered customer's email to associate the shipment with that account. If left blank, the record is not visible in a customer's dashboard, but limited public tracking still works.
- Enter origin/destination and coordinate pairs when available. Latitude and longitude must be supplied together.
- Choose Sea Freight, Air Freight, or Land Transport and a status, then save.
- The database creates the tracking number automatically and records creation history.
- Edit a shipment to update status, current location and coordinates, route, delivery estimate, transport method, or notes. The database audit trigger records status/location/transport/route changes.
- Public tracking reveals only limited operational information. An authenticated assigned customer can see the private fields permitted by RLS.

## 5. Maps and route services

- Map rendering: Leaflet + OpenStreetMap tiles (no key in this demo).
- Land routing: OSRM public demo service (`router.project-osrm.org`). Replace with a production routing provider before high-volume commercial use.
- Air: illustrative origin-to-destination line only; no live plane position.
- Sea: approximate origin-to-destination corridor only; no maritime routing data is integrated.
- Coordinates are entered by an administrator. This project does not geocode arbitrary place names or invent missing coordinates.

## 6. Backups and production hardening

- Enable Supabase automated backups appropriate to your plan and periodically export critical shipment data.
- Require email confirmation and MFA for the administrator account.
- Configure a custom domain and HTTPS.
- Add a rate-limited server-side tracking endpoint/Edge Function before exposing public tracking to significant traffic.
- Consider CAPTCHA/abuse prevention, audit-log retention, monitoring, privacy/legal review, and a private Storage bucket for proof-of-delivery files.
- Keep dependencies updated and never commit private service keys.

## 7. Verification checklist after connecting your own project

- Register a regular customer and confirm the profile role is `customer` in `public.profiles`.
- Register/confirm `nosadpe@gmail.com` and confirm the role is `admin`.
- Sign in as the admin, create a shipment, and confirm its tracking number is generated by the database.
- Assign it to the test customer's registered email and verify the customer sees it after sign-in.
- Change status, transport and location; refresh and confirm all values and history persist.
- As the customer, try opening a different customer's shipment ID and directly calling shipment update APIs; RLS should deny access.
- Use public tracking and verify that recipient address, phone, names and customer identity are not returned.
- Test on actual iOS Safari and Android Chrome after deployment.
