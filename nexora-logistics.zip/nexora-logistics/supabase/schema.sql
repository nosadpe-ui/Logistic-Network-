-- NEXORA LOGISTICS / LOGISTICS NETWORK
-- Run in Supabase SQL Editor. This schema enforces customer/admin access in PostgreSQL.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text not null unique,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.shipments (
  id uuid primary key default gen_random_uuid(),
  tracking_number text not null unique,
  shipment_reference text,
  customer_id uuid references public.profiles(id) on delete set null,
  sender_name text,
  sender_email text,
  recipient_name text,
  recipient_email text,
  recipient_phone text,
  destination_address text,
  origin_country text not null,
  origin_city text not null,
  origin_terminal text,
  origin_lat double precision,
  origin_lng double precision,
  destination_country text not null,
  destination_city text not null,
  destination_terminal text,
  destination_lat double precision,
  destination_lng double precision,
  current_location text,
  current_lat double precision,
  current_lng double precision,
  status text not null default 'Pending' check (status in ('Pending','Processing','In Transit','Moving','Out for Delivery','Delivered','On Hold')),
  transport_method text not null check (transport_method in ('Sea Freight','Air Freight','Land Transport')),
  estimated_delivery date,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.shipment_events (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipments(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  event_type text not null,
  description text not null,
  previous_value jsonb,
  new_value jsonb,
  event_time timestamptz not null default now()
);

create table if not exists public.company_settings (
  id integer primary key default 1 check (id = 1),
  company_name text not null default 'LOGISTICS NETWORK',
  contact_email text,
  telephone text,
  business_address text,
  logo_url text,
  updated_at timestamptz not null default now()
);
insert into public.company_settings(id, company_name) values (1, 'LOGISTICS NETWORK') on conflict (id) do nothing;

create index if not exists shipments_customer_id_idx on public.shipments(customer_id);
create index if not exists shipments_tracking_idx on public.shipments(tracking_number);
create index if not exists shipment_events_shipment_time_idx on public.shipment_events(shipment_id, event_time desc);

-- New signups are customers by default. Only the exact allowlisted email is promoted by this
-- trusted database trigger; clients cannot choose their own role.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, full_name, email, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name',''),
    lower(new.email),
    case when lower(new.email) = 'nosadpe@gmail.com' and new.email_confirmed_at is not null then 'admin' else 'customer' end
  );
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select lower(coalesce(auth.jwt() ->> 'email','')) = 'nosadpe@gmail.com'
  and exists(select 1 from public.profiles where id = auth.uid() and role = 'admin' and lower(email) = 'nosadpe@gmail.com'); $$;

alter table public.profiles enable row level security;
alter table public.shipments enable row level security;
alter table public.shipment_events enable row level security;
alter table public.company_settings enable row level security;

-- Profiles: customers can read/update their own non-role fields; admins can read all.
drop policy if exists "profile self read" on public.profiles;
create policy "profile self read" on public.profiles for select to authenticated using (id = auth.uid() or public.is_admin());
drop policy if exists "profile self update" on public.profiles;
create policy "profile self update" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid() and role = 'customer');
drop policy if exists "admin profile read" on public.profiles;
create policy "admin profile read" on public.profiles for select to authenticated using (public.is_admin());

-- Shipments: only assigned customers and admins can read; only admins can write.
drop policy if exists "customer reads own shipments" on public.shipments;
create policy "customer reads own shipments" on public.shipments for select to authenticated using (customer_id = auth.uid() or public.is_admin());
drop policy if exists "admin creates shipments" on public.shipments;
create policy "admin creates shipments" on public.shipments for insert to authenticated with check (public.is_admin());
drop policy if exists "admin updates shipments" on public.shipments;
create policy "admin updates shipments" on public.shipments for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin deletes shipments" on public.shipments;
create policy "admin deletes shipments" on public.shipments for delete to authenticated using (public.is_admin());

-- Events: customers see history only for their own shipments; admins manage history.
drop policy if exists "customer reads own events" on public.shipment_events;
create policy "customer reads own events" on public.shipment_events for select to authenticated
using (exists(select 1 from public.shipments s where s.id = shipment_id and (s.customer_id = auth.uid() or public.is_admin())));
drop policy if exists "admin inserts events" on public.shipment_events;
create policy "admin inserts events" on public.shipment_events for insert to authenticated with check (public.is_admin());
drop policy if exists "admin manages events" on public.shipment_events;
create policy "admin manages events" on public.shipment_events for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Public tracking RPC deliberately returns only non-sensitive tracking fields.
create or replace function public.public_track_shipment(p_tracking_number text)
returns jsonb language plpgsql security definer set search_path = public
as $$
declare s public.shipments%rowtype; ev jsonb;
begin
  select * into s from public.shipments where upper(tracking_number) = upper(trim(p_tracking_number));
  if not found then return null; end if;
  select coalesce(jsonb_agg(jsonb_build_object(
    'event_type', e.event_type, 'description', e.description,
    'event_time', e.event_time, 'new_value', e.new_value
  ) order by e.event_time asc), '[]'::jsonb)
  into ev from public.shipment_events e where e.shipment_id = s.id;
  return jsonb_build_object(
    'tracking_number', s.tracking_number,
    'shipment_reference', s.shipment_reference,
    'origin_city', s.origin_city, 'origin_country', s.origin_country,
    'destination_city', s.destination_city, 'destination_country', s.destination_country,
    'current_location', s.current_location, 'current_lat', s.current_lat, 'current_lng', s.current_lng,
    'origin_lat', s.origin_lat, 'origin_lng', s.origin_lng,
    'destination_lat', s.destination_lat, 'destination_lng', s.destination_lng,
    'status', s.status, 'transport_method', s.transport_method,
    'estimated_delivery', s.estimated_delivery, 'updated_at', s.updated_at,
    'history', ev
  );
end;
$$;
grant execute on function public.public_track_shipment(text) to anon, authenticated;

-- Company contact details are public; only admins may change them.
drop policy if exists "public reads company settings" on public.company_settings;
create policy "public reads company settings" on public.company_settings for select to anon, authenticated using (true);
drop policy if exists "admin updates company settings" on public.company_settings;
create policy "admin updates company settings" on public.company_settings for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Prevent clients from changing role through direct profile updates.
revoke all on public.profiles from anon;
grant select, update on public.profiles to authenticated;
grant select, insert, update, delete on public.shipments to authenticated;
grant select, insert, update, delete on public.shipment_events to authenticated;
grant select on public.company_settings to anon, authenticated;
grant update on public.company_settings to authenticated;

-- Audit important shipment changes in the database, so history is persisted even if a UI
-- request is interrupted after the shipment update. Customers cannot write these events.
create or replace function public.audit_shipment_changes()
returns trigger language plpgsql security definer set search_path = public
as $$
declare actor uuid := auth.uid();
begin
  if tg_op = 'INSERT' then
    insert into public.shipment_events(shipment_id, actor_id, event_type, description, new_value)
    values (new.id, actor, 'shipment_created', 'Shipment record created.',
      jsonb_build_object('status',new.status,'transport_method',new.transport_method));
    return new;
  end if;
  if new.status is distinct from old.status then
    insert into public.shipment_events(shipment_id,actor_id,event_type,description,previous_value,new_value)
    values(new.id,actor,'status_changed','Shipment status updated.',to_jsonb(old.status),to_jsonb(new.status));
  end if;
  if new.current_location is distinct from old.current_location or new.current_lat is distinct from old.current_lat or new.current_lng is distinct from old.current_lng then
    insert into public.shipment_events(shipment_id,actor_id,event_type,description,previous_value,new_value)
    values(new.id,actor,'location_changed','Shipment location updated.',
      jsonb_build_object('location',old.current_location,'lat',old.current_lat,'lng',old.current_lng),
      jsonb_build_object('location',new.current_location,'lat',new.current_lat,'lng',new.current_lng));
  end if;
  if new.transport_method is distinct from old.transport_method then
    insert into public.shipment_events(shipment_id,actor_id,event_type,description,previous_value,new_value)
    values(new.id,actor,'transport_changed','Transport method updated.',to_jsonb(old.transport_method),to_jsonb(new.transport_method));
  end if;
  if new.origin_city is distinct from old.origin_city or new.origin_country is distinct from old.origin_country or new.destination_city is distinct from old.destination_city or new.destination_country is distinct from old.destination_country then
    insert into public.shipment_events(shipment_id,actor_id,event_type,description,previous_value,new_value)
    values(new.id,actor,'route_changed','Shipment route details updated.',
      jsonb_build_object('origin_city',old.origin_city,'origin_country',old.origin_country,'destination_city',old.destination_city,'destination_country',old.destination_country),
      jsonb_build_object('origin_city',new.origin_city,'origin_country',new.origin_country,'destination_city',new.destination_city,'destination_country',new.destination_country));
  end if;
  return new;
end;
$$;
drop trigger if exists shipment_audit_trigger on public.shipments;
create trigger shipment_audit_trigger after insert or update on public.shipments
for each row execute procedure public.audit_shipment_changes();

-- Public tracking returns a deliberately small, non-sensitive event projection. It does not
-- return event descriptions, arbitrary JSON values, customer identity, addresses, or phone data.
create or replace function public.public_track_shipment(p_tracking_number text)
returns jsonb language plpgsql security definer set search_path = public
as $$
declare s public.shipments%rowtype; ev jsonb;
begin
  select * into s from public.shipments where upper(tracking_number) = upper(trim(p_tracking_number));
  if not found then return null; end if;
  select coalesce(jsonb_agg(jsonb_build_object(
    'event_type', e.event_type, 'event_time', e.event_time
  ) order by e.event_time asc), '[]'::jsonb)
  into ev from public.shipment_events e where e.shipment_id = s.id;
  return jsonb_build_object(
    'tracking_number', s.tracking_number,
    'shipment_reference', s.shipment_reference,
    'origin_city', s.origin_city, 'origin_country', s.origin_country,
    'destination_city', s.destination_city, 'destination_country', s.destination_country,
    'current_location', s.current_location, 'current_lat', s.current_lat, 'current_lng', s.current_lng,
    'origin_lat', s.origin_lat, 'origin_lng', s.origin_lng,
    'destination_lat', s.destination_lat, 'destination_lng', s.destination_lng,
    'status', s.status, 'transport_method', s.transport_method,
    'estimated_delivery', s.estimated_delivery, 'updated_at', s.updated_at,
    'history', ev
  );
end;
$$;
grant execute on function public.public_track_shipment(text) to anon, authenticated;

-- Tracking references are generated inside PostgreSQL, never trusted from the browser.
create or replace function public.generate_shipment_tracking_number()
returns trigger language plpgsql set search_path = public
as $$
begin
  new.tracking_number := 'LN-' || to_char(now() at time zone 'utc','YYYY') || '-' || upper(encode(gen_random_bytes(12),'hex'));
  return new;
end;
$$;
drop trigger if exists shipment_tracking_number_trigger on public.shipments;
create trigger shipment_tracking_number_trigger before insert on public.shipments
for each row execute procedure public.generate_shipment_tracking_number();


-- Promote the allowlisted administrator only after Supabase confirms ownership of that email.
create or replace function public.promote_verified_admin_email()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if new.email_confirmed_at is not null
     and (old.email_confirmed_at is null or lower(new.email) is distinct from lower(old.email))
     and lower(new.email) = 'nosadpe@gmail.com' then
    update public.profiles set role = 'admin', email = lower(new.email) where id = new.id;
  end if;
  return new;
end;
$$;
drop trigger if exists promote_verified_admin_email_trigger on auth.users;
create trigger promote_verified_admin_email_trigger
  after update of email_confirmed_at, email on auth.users
  for each row execute procedure public.promote_verified_admin_email();
