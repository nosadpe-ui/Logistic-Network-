(() => {
  'use strict';
  const cfg = window.APP_CONFIG || {};
  const configured = cfg.SUPABASE_URL && !cfg.SUPABASE_URL.includes('YOUR-PROJECT') && cfg.SUPABASE_ANON_KEY && !cfg.SUPABASE_ANON_KEY.includes('YOUR_');
  const $ = id => document.getElementById(id);
  const statuses = ['Pending','Processing','In Transit','Moving','Out for Delivery','Delivered','On Hold'];
  const methods = ['Sea Freight','Air Freight','Land Transport'];
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let supabase = null, currentUser = null, currentProfile = null, toastTimer = null, detailMap = null, detailLayer = null;
  if (configured && window.supabase) supabase = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY, {auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
  const showToast = (message, bad=false) => { const el=$('toast'); el.textContent=message; el.style.background=bad?'#8d2930':'#102f4a'; el.classList.add('show'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove('show'),3500); };
  const setNotice = (id,msg,ok=false) => { const el=$(id); if(!el)return; el.textContent=msg||''; el.className='notice'+(ok?' success':''); };
  const busy = (button,on,label) => { if(!button)return; if(on){button.dataset.label=button.textContent;button.textContent=label||'Please wait…';button.disabled=true;}else{button.textContent=button.dataset.label||button.textContent;button.disabled=false;} };
  const fmt = value => value ? new Date(value).toLocaleString() : 'Not available';
  const val = id => ($(id)?.value || '').trim();
  const coords = (lat,lng) => Number.isFinite(Number(lat)) && Number.isFinite(Number(lng)) && lat!==null && lng!==null && valNumber(lat)>=-90 && valNumber(lat)<=90 && valNumber(lng)>=-180 && valNumber(lng)<=180;
  const valNumber = n => Number(n);
  const point = (lat,lng) => coords(lat,lng) ? [Number(lat),Number(lng)] : null;
  const errText = error => error?.message || 'Something went wrong. Please try again.';
  const isAdmin = () => currentProfile?.role === 'admin' && currentUser?.email?.toLowerCase() === (cfg.ADMIN_EMAIL||'nosadpe@gmail.com').toLowerCase();

  function setView(view){
    $('authView').classList.toggle('hidden',!['login','register'].includes(view));
    $('portalView').classList.toggle('hidden',view!=='portal');
    document.querySelectorAll('main>section:not(#authView):not(#portalView)').forEach(s=>s.classList.toggle('hidden',['login','register','portal'].includes(view)));
    if(view==='login'||view==='register'){
      const reg=view==='register'; $('authTitle').textContent=reg?'Create your account':'Welcome back';
      $('authSubtitle').textContent=reg?'Register to access your shipment information.':'Sign in to view your shipments.';
      $('nameField').classList.toggle('hidden',!reg); $('confirmField').classList.toggle('hidden',!reg);
      $('fullName').required=reg; $('confirmPassword').required=reg; $('authPassword').autocomplete=reg?'new-password':'current-password';
      $('authSubmit').textContent=reg?'Create account':'Login'; $('authSwitch').innerHTML=reg?'Already registered? <button data-view="login">Sign in</button>':'New to LOGISTICS NETWORK? <button data-view="register">Create an account</button>';
      setNotice('authMessage',''); window.scrollTo({top:0,behavior:'smooth'});
    }
    if(view==='portal'){window.scrollTo({top:0,behavior:'smooth'});}
  }
  document.addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(b){setView(b.dataset.view);$('mainNav').classList.remove('open');}});
  $('menuToggle').addEventListener('click',()=>$('mainNav').classList.toggle('open'));
  $('backHome').addEventListener('click',()=>setView('home'));
  $('year').textContent=new Date().getFullYear();

  async function loadProfile(user){
    const {data,error}=await supabase.from('profiles').select('id,full_name,email,role').eq('id',user.id).single();
    if(error)throw error; currentProfile=data;
    if(user.email.toLowerCase()!== (cfg.ADMIN_EMAIL||'nosadpe@gmail.com').toLowerCase() && data.role==='admin'){
      throw new Error('This account is not permitted to use administrator access.');
    }
  }
  async function handleAuth(){
    if(!supabase)return;
    const {data:{session}}=await supabase.auth.getSession();
    if(session){currentUser=session.user;try{await loadProfile(currentUser);await openPortal();}catch(e){showToast(errText(e),true);await supabase.auth.signOut();currentUser=null;currentProfile=null;}}
    const {data:{subscription}}=supabase.auth.onAuthStateChange(async(_event,session)=>{
      if(session?.user){currentUser=session.user;setTimeout(async()=>{try{await loadProfile(currentUser);await openPortal();}catch(e){showToast(errText(e),true);}},0);}
      else{currentUser=null;currentProfile=null;setView('home');}
    });
    window.addEventListener('beforeunload',()=>subscription.unsubscribe());
  }
  $('authForm').addEventListener('submit',async e=>{
    e.preventDefault(); if(!supabase){setNotice('authMessage','Connect Supabase first using the setup instructions.');return;}
    const button=$('authSubmit'),email=val('authEmail').toLowerCase(),password=val('authPassword'),register=!$('confirmField').classList.contains('hidden');
    if(register && password!==val('confirmPassword')){setNotice('authMessage','Your passwords do not match.');return;}
    busy(button,true,register?'Creating account…':'Signing in…');setNotice('authMessage','');
    try{
      if(register){const {data,error}=await supabase.auth.signUp({email,password,options:{data:{full_name:val('fullName')}}});if(error)throw error;
        if(data.session){currentUser=data.user;await loadProfile(currentUser);await openPortal();showToast('Your account has been created.');}
        else setNotice('authMessage','Registration received. Check your email to confirm your account before signing in.',true);
      }else{const {data,error}=await supabase.auth.signInWithPassword({email,password});if(error)throw error;currentUser=data.user;await loadProfile(currentUser);await openPortal();showToast('Signed in successfully.');}
    }catch(error){setNotice('authMessage',errText(error));}finally{busy(button,false);}
  });
  $('logoutBtn').addEventListener('click',async()=>{if(supabase)await supabase.auth.signOut();currentUser=null;currentProfile=null;setView('home');showToast('You have signed out.');});

  async function openPortal(){
    if(!currentUser)return;setView('portal');
    const admin=isAdmin();$('adminPanel').classList.toggle('hidden',!admin);$('customerPanel').classList.toggle('hidden',admin);
    $('portalTitle').textContent=admin?'Administrator dashboard':'Your shipments';$('portalSubtitle').textContent=admin?'Manage shipment records and company settings.':'Shipment information linked to your account.';
    if(admin){await loadAdmin();await loadSettings();}else await loadCustomer();
  }
  async function loadCustomer(){
    const {data,error}=await supabase.from('shipments').select('id,tracking_number,status,transport_method,origin_city,origin_country,destination_city,destination_country,current_location,estimated_delivery,updated_at').eq('customer_id',currentUser.id).order('updated_at',{ascending:false});
    if(error){$('customerShipments').innerHTML=`<div class="empty-state">${esc(errText(error))}</div>`;return;}
    renderRows('customerShipments',data||[],false);
  }
  $('refreshCustomer').addEventListener('click',loadCustomer);
  $('customerSearch').addEventListener('input',()=>filterRows('customerShipments',$('customerSearch').value));
  $('adminSearch').addEventListener('input',()=>filterRows('adminShipments',$('adminSearch').value));
  $('adminStatusFilter').addEventListener('change',loadAdmin);
  function filterRows(id,q){document.querySelectorAll(`#${id} .shipment-row`).forEach(el=>el.classList.toggle('hidden',!el.dataset.search.includes(q.toLowerCase())));}
  function renderRows(id,rows,admin){
    const host=$(id);if(!rows.length){host.innerHTML='<div class="empty-state">No shipments found yet.</div>';return;}
    host.innerHTML=rows.map(s=>`<article class="shipment-row" data-search="${esc((s.tracking_number+' '+s.destination_city+' '+s.destination_country).toLowerCase())}"><div><h4>${esc(s.tracking_number)}</h4><p>${esc(s.origin_city)}, ${esc(s.origin_country)} → ${esc(s.destination_city)}, ${esc(s.destination_country)}</p><p>${esc(s.transport_method)} · ${esc(s.current_location||'Location not updated')}</p><span class="status-pill ${s.status==='Delivered'?'status-delivered':s.status==='On Hold'?'status-hold':''}">${esc(s.status)}</span></div><div class="row-actions"><button class="small-action" data-detail="${esc(s.id)}">View details</button>${admin?`<button class="small-action" data-edit="${esc(s.id)}">Edit</button>`:''}</div></article>`).join('');
  }
  document.addEventListener('click',e=>{const d=e.target.closest('[data-detail]');if(d)showDetails(d.dataset.detail);const ed=e.target.closest('[data-edit]');if(ed)editShipment(ed.dataset.edit);});
  async function loadAdmin(){
    if(!isAdmin())return;
    let query=supabase.from('shipments').select('*').order('created_at',{ascending:false});const status=$('adminStatusFilter').value;if(status)query=query.eq('status',status);
    const {data,error}=await query;if(error){$('adminShipments').innerHTML=`<div class="empty-state">${esc(errText(error))}</div>`;return;}
    const all=data||[];const counts={Total:all.length};statuses.forEach(s=>counts[s]=all.filter(x=>x.status===s).length);
    $('statsGrid').innerHTML=[['Total shipments',counts.Total],...statuses.map(s=>[s,counts[s]])].map(([k,v])=>`<div class="stat-card"><b>${v}</b><small>${esc(k)}</small></div>`).join('');
    renderRows('adminShipments',all,true);filterRows('adminShipments',$('adminSearch').value);
  }
  async function loadSettings(){const {data,error}=await supabase.from('company_settings').select('*').eq('id',1).single();if(error)return;const f=$('settingsForm');f.company_name.value=data.company_name||'LOGISTICS NETWORK';f.contact_email.value=data.contact_email||'';f.telephone.value=data.telephone||'';f.business_address.value=data.business_address||'';renderContact(data);}
  function renderContact(s){$('contactDetails').innerHTML=[s.contact_email?`<div>Email: <a href="mailto:${esc(s.contact_email)}">${esc(s.contact_email)}</a></div>`:'',s.telephone?`<div>Telephone: ${esc(s.telephone)}</div>`:'',s.business_address?`<div>Address: ${esc(s.business_address)}</div>`:''].filter(Boolean).join('')||'Company contact details have not been published yet.';}
  $('settingsForm').addEventListener('submit',async e=>{e.preventDefault();if(!isAdmin())return;const f=e.currentTarget;const payload={company_name:f.company_name.value.trim(),contact_email:f.contact_email.value.trim()||null,telephone:f.telephone.value.trim()||null,business_address:f.business_address.value.trim()||null,updated_at:new Date().toISOString()};const {data,error}=await supabase.from('company_settings').update(payload).eq('id',1).select().single();if(error){setNotice('settingsMessage',errText(error));return;}setNotice('settingsMessage','Company settings saved.',true);renderContact(data);showToast('Company settings saved.');});

  function openShipmentModal(){ $('shipmentForm').reset();$('shipmentId').value='';$('modalTitle').textContent='Create shipment';$('saveShipment').textContent='Create shipment';$('shipmentModal').classList.remove('hidden');setNotice('shipmentMessage',''); }
  $('newShipmentBtn').addEventListener('click',openShipmentModal);['closeModal','cancelShipment'].forEach(id=>$(id).addEventListener('click',()=>$('shipmentModal').classList.add('hidden')));
  async function editShipment(id){const {data,error}=await supabase.from('shipments').select('*').eq('id',id).single();if(error){showToast(errText(error),true);return;}openShipmentModal();$('modalTitle').textContent='Edit shipment';$('saveShipment').textContent='Save changes';$('shipmentId').value=data.id;
    const map={customerEmail:'customer_id',shipmentReference:'shipment_reference',senderName:'sender_name',recipientName:'recipient_name',recipientEmail:'recipient_email',recipientPhone:'recipient_phone',originCity:'origin_city',originCountry:'origin_country',originTerminal:'origin_terminal',originLat:'origin_lat',originLng:'origin_lng',destinationCity:'destination_city',destinationCountry:'destination_country',destinationTerminal:'destination_terminal',destinationLat:'destination_lat',destinationLng:'destination_lng',destinationAddress:'destination_address',currentLocation:'current_location',currentLat:'current_lat',currentLng:'current_lng',transportMethod:'transport_method',shipmentStatus:'status',estimatedDelivery:'estimated_delivery',shipmentNotes:'notes'};
    // Customer is a UUID in the database; resolve it to an email for the editable field.
    if(data.customer_id){const {data:p}=await supabase.from('profiles').select('email').eq('id',data.customer_id).maybeSingle();$('customerEmail').value=p?.email||'';}else $('customerEmail').value='';
    Object.entries(map).forEach(([field,key])=>{if(field!=='customerEmail')$(field).value=data[key]??'';});
  }
  function numberOrNull(id){const v=val(id);return v===''?null:Number(v);}
  async function customerIdFromEmail(email){if(!email)return null;const {data,error}=await supabase.from('profiles').select('id').eq('email',email.toLowerCase()).maybeSingle();if(error)throw error;if(!data)throw new Error('No registered customer has that email address. Leave the field blank or register the customer first.');return data.id;}
  $('shipmentForm').addEventListener('submit',async e=>{
    e.preventDefault();if(!isAdmin()){setNotice('shipmentMessage','Administrator permission required.');return;}
    const btn=$('saveShipment');busy(btn,true,'Saving…');setNotice('shipmentMessage','');
    try{
      const customerId=await customerIdFromEmail(val('customerEmail'));
      const payload={customer_id:customerId,shipment_reference:val('shipmentReference')||null,sender_name:val('senderName')||null,recipient_name:val('recipientName')||null,recipient_email:val('recipientEmail')||null,recipient_phone:val('recipientPhone')||null,origin_city:val('originCity'),origin_country:val('originCountry'),origin_terminal:val('originTerminal')||null,origin_lat:numberOrNull('originLat'),origin_lng:numberOrNull('originLng'),destination_city:val('destinationCity'),destination_country:val('destinationCountry'),destination_terminal:val('destinationTerminal')||null,destination_lat:numberOrNull('destinationLat'),destination_lng:numberOrNull('destinationLng'),destination_address:val('destinationAddress')||null,current_location:val('currentLocation')||null,current_lat:numberOrNull('currentLat'),current_lng:numberOrNull('currentLng'),transport_method:val('transportMethod'),status:val('shipmentStatus'),estimated_delivery:val('estimatedDelivery')||null,notes:val('shipmentNotes')||null,updated_at:new Date().toISOString()};
      ['origin','destination','current'].forEach(prefix=>{const a=payload[prefix+'_lat'],b=payload[prefix+'_lng'];if((a===null)!==(b===null))throw new Error(`Enter both ${prefix} latitude and longitude, or leave both blank.`);if(a!==null&&!coords(a,b))throw new Error(`The ${prefix} coordinates are invalid.`);});
      const id=val('shipmentId');let saved;
      if(id){const {data,error}=await supabase.from('shipments').update(payload).eq('id',id).select().single();if(error)throw error;saved=data;}
      else{const {data,error}=await supabase.from('shipments').insert(payload).select().single();if(error)throw error;saved=data;}
      $('shipmentModal').classList.add('hidden');showToast(id?'Shipment saved.':`Shipment created. Tracking number: ${saved.tracking_number}`);await loadAdmin();
    }catch(error){setNotice('shipmentMessage',errText(error));}finally{busy(btn,false);}
  });
  async function addEvent(shipmentId,type,description,previousValue,newValue){const {error}=await supabase.from('shipment_events').insert({shipment_id:shipmentId,actor_id:currentUser.id,event_type:type,description,previous_value:previousValue,new_value:newValue});if(error)throw error;}

  async function showDetails(id){
    const publicOnly=!currentUser;let shipment,events=[];
    if(publicOnly){showToast('Please track by number from the homepage.');return;}
    const {data,error}=await supabase.from('shipments').select('*').eq('id',id).single();if(error){showToast(errText(error),true);return;}
    shipment=data;const {data:ev}=await supabase.from('shipment_events').select('event_type,description,event_time,previous_value,new_value').eq('shipment_id',id).order('event_time',{ascending:true});events=ev||[];
    $('detailTitle').textContent=shipment.tracking_number;
    $('detailContent').innerHTML=detailHtml(shipment,events,true);$('detailModal').classList.remove('hidden');drawMap('detailMap',shipment);
  }
  function detailHtml(s,events,privateAccess){
    const fields=[['Status',s.status],['Transport',s.transport_method],['Origin',`${s.origin_city}, ${s.origin_country}`],['Destination',`${s.destination_city}, ${s.destination_country}`],['Current location',s.current_location||'Not updated'],['Estimated delivery',s.estimated_delivery||'Not available'],['Last updated',fmt(s.updated_at)]];
    if(privateAccess){if(s.sender_name)fields.push(['Sender',s.sender_name]);if(s.recipient_name)fields.push(['Recipient',s.recipient_name]);if(s.destination_address)fields.push(['Delivery address',s.destination_address]);}
    return `<div class="tracking-grid">${fields.map(([k,v])=>`<div><small>${esc(k)}</small><b>${esc(v)}</b></div>`).join('')}</div><div id="detailMap" class="map"></div><div class="map-note" id="mapNote">Map route availability depends on transport mode and available coordinates.</div><h3 style="color:var(--navy)">Shipment history</h3>${events.length?`<div class="timeline">${events.map(ev=>`<div class="timeline-item"><b>${esc(ev.description)}</b><p>${esc(ev.event_type.replaceAll('_',' '))}</p><time>${esc(fmt(ev.event_time))}</time></div>`).join('')}</div>`:'<div class="empty-state">No tracking updates are available yet.</div>'}`;
  }
  $('closeDetail').addEventListener('click',()=>{$('detailModal').classList.add('hidden');if(detailMap){detailMap.remove();detailMap=null;}});

  async function drawMap(containerId,s){
    if(!window.L){$('mapNote').textContent='The map library could not be loaded. Shipment details remain available.';return;}
    if(detailMap){detailMap.remove();detailMap=null;}
    const map=L.map(containerId,{scrollWheelZoom:false});detailMap=map;L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'}).addTo(map);
    const o=point(s.origin_lat,s.origin_lng),d=point(s.destination_lat,s.destination_lng),c=point(s.current_lat,s.current_lng),bounds=[];
    if(o){L.marker(o).addTo(map).bindPopup('Origin');bounds.push(o);}if(d){L.marker(d).addTo(map).bindPopup('Destination');bounds.push(d);}if(c){const red=L.divIcon({className:'',html:'<div style="width:18px;height:18px;background:#df3038;border:3px solid white;border-radius:50%;box-shadow:0 1px 7px #333"></div>',iconSize:[18,18],iconAnchor:[9,9]});L.marker(c,{icon:red}).addTo(map).bindPopup('Latest saved shipment location');bounds.push(c);}
    let note='Markers show only saved shipment coordinates.';
    if(o&&d){
      if(s.transport_method==='Land Transport'){
        try{const url=`https://router.project-osrm.org/route/v1/driving/${o[1]},${o[0]};${d[1]},${d[0]}?overview=full&geometries=geojson`;const r=await fetch(url);if(!r.ok)throw new Error('Road route service unavailable');const json=await r.json();if(json.code!=='Ok'||!json.routes?.length)throw new Error('No road route found');const coords=json.routes[0].geometry.coordinates.map(x=>[x[1],x[0]]);L.polyline(coords,{color:'#1769aa',weight:4}).addTo(map);coords.forEach(x=>bounds.push(x));note='Road route supplied by OSRM. Confirm actual carrier routing separately.';}catch(_){note='A road route could not be calculated. Saved shipment markers are shown instead.';}
      }else if(s.transport_method==='Air Freight'){L.polyline([o,d],{color:'#2584ce',weight:3,dashArray:'8 8'}).addTo(map);note='Illustrative direct air corridor only; not a live flight path or operational flight plan.';}
      else{L.polyline([o,d],{color:'#178a75',weight:3,dashArray:'3 9'}).addTo(map);note='Approximate sea-freight corridor only. This is not a verified maritime route; port/sea-lane routing data is not connected.';}
    }else note='Add valid origin and destination coordinates to display a planned route. The current marker appears only when saved coordinates exist.';
    $('mapNote').textContent=note;if(bounds.length)map.fitBounds(bounds,{padding:[25,25],maxZoom:8});else map.setView([15,0],2);setTimeout(()=>map.invalidateSize(),150);
  }

  function publicEventLabel(type){return ({shipment_created:'Shipment record created',status_changed:'Shipment status updated',location_changed:'Shipment location updated',transport_changed:'Transport method updated',route_changed:'Shipment route details updated'})[type]||'Shipment update';}
  async function publicTrack(number){
    if(!supabase)throw new Error('Tracking is not connected yet. The website owner must configure Supabase.');
    const {data,error}=await supabase.rpc('public_track_shipment',{p_tracking_number:number});if(error)throw error;if(!data)throw new Error('We couldn’t find a shipment with that tracking number. Please check the number and try again.');return data;
  }
  $('trackForm').addEventListener('submit',async e=>{
    e.preventDefault();const btn=e.submitter||e.currentTarget.querySelector('button');busy(btn,true,'Searching…');$('trackResult').innerHTML='';
    try{const s=await publicTrack(val('trackingInput'));$('trackResult').innerHTML=`<div class="tracking-card"><div class="tracking-top"><div><span class="eyebrow">SHIPMENT FOUND</span><h3>${esc(s.tracking_number)}</h3></div><span class="status-pill ${s.status==='Delivered'?'status-delivered':s.status==='On Hold'?'status-hold':''}">${esc(s.status)}</span></div><div class="tracking-grid">${[['Origin',`${s.origin_city}, ${s.origin_country}`],['Destination',`${s.destination_city}, ${s.destination_country}`],['Current location',s.current_location||'Not updated'],['Transport',s.transport_method],['Estimated delivery',s.estimated_delivery||'Not available'],['Last update',fmt(s.updated_at)]].map(([k,v])=>`<div><small>${esc(k)}</small><b>${esc(v)}</b></div>`).join('')}</div><div id="publicMap" class="map"></div><div id="publicMapNote" class="map-note">Map is loading…</div><h3 style="color:var(--navy);margin-top:20px">Tracking history</h3>${s.history?.length?`<div class="timeline">${s.history.map(ev=>`<div class="timeline-item"><b>${esc(publicEventLabel(ev.event_type))}</b><time>${esc(fmt(ev.event_time))}</time></div>`).join('')}</div>`:'<div class="empty-state">No shipment updates are available yet. Please check again later.</div>'}</div>`;await drawPublicMap(s);}
    catch(error){$('trackResult').innerHTML=`<div class="tracking-card" style="color:#9b3339">${esc(errText(error))}</div>`;}finally{busy(btn,false);}
  });
  async function drawPublicMap(s){if(!window.L){$('publicMapNote').textContent='Map could not load. Shipment details are still available.';return;}const map=L.map('publicMap',{scrollWheelZoom:false});L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap contributors'}).addTo(map);const o=point(s.origin_lat,s.origin_lng),d=point(s.destination_lat,s.destination_lng),c=point(s.current_lat,s.current_lng),bounds=[];if(o){L.marker(o).addTo(map).bindPopup('Origin');bounds.push(o);}if(d){L.marker(d).addTo(map).bindPopup('Destination');bounds.push(d);}if(c){L.marker(c,{icon:L.divIcon({className:'',html:'<div style="width:18px;height:18px;background:#df3038;border:3px solid white;border-radius:50%"></div>',iconSize:[18,18],iconAnchor:[9,9]})}).addTo(map).bindPopup('Latest saved shipment location');bounds.push(c);}let note='Markers represent saved shipment coordinates.';if(o&&d){if(s.transport_method==='Land Transport'){try{const r=await fetch(`https://router.project-osrm.org/route/v1/driving/${o[1]},${o[0]};${d[1]},${d[0]}?overview=full&geometries=geojson`);const j=await r.json();if(j.code!=='Ok')throw 0;const line=j.routes[0].geometry.coordinates.map(x=>[x[1],x[0]]);L.polyline(line,{color:'#1769aa',weight:4}).addTo(map);line.forEach(p=>bounds.push(p));note='Road route from OSRM; carrier route may differ.';}catch{note='Road route unavailable; saved markers are shown.';}}else if(s.transport_method==='Air Freight'){L.polyline([o,d],{color:'#2584ce',dashArray:'8 8'}).addTo(map);note='Illustrative direct air corridor, not live flight tracking.';}else{L.polyline([o,d],{color:'#178a75',dashArray:'3 9'}).addTo(map);note='Approximate sea corridor, not a verified maritime route.';}}else note='Route unavailable until origin and destination coordinates are saved.';$('publicMapNote').textContent=note;if(bounds.length)map.fitBounds(bounds,{padding:[25,25],maxZoom:8});else map.setView([15,0],2);setTimeout(()=>map.invalidateSize(),150);}

  $('contactForm').addEventListener('submit',e=>{e.preventDefault();const f=e.currentTarget;const details=[...$('contactDetails').querySelectorAll('div')].map(x=>x.textContent).join('\n');const subject=encodeURIComponent('LOGISTICS NETWORK website enquiry');const body=encodeURIComponent(`Name: ${f.name.value}\nEmail: ${f.email.value}\n\n${f.message.value}\n\n${details}`);const email=$('contactDetails').querySelector('a')?.textContent;if(!email){showToast('Company email has not been configured yet.',true);return;}window.location.href=`mailto:${encodeURIComponent(email)}?subject=${subject}&body=${body}`;});

  // Contact information is public, but private shipment fields are never selected here.
  if(supabase){supabase.from('company_settings').select('company_name,contact_email,telephone,business_address').eq('id',1).single().then(({data})=>{if(data)renderContact(data);});handleAuth().catch(e=>showToast(errText(e),true));}
  else{ $('contactDetails').textContent='Connect this website to Supabase to publish company contact information.'; }
  if(!configured){const warning=document.createElement('div');warning.style.cssText='position:fixed;left:12px;right:12px;bottom:12px;background:#fff4d9;color:#684a08;border:1px solid #e8d18e;border-radius:9px;padding:12px 15px;z-index:150;font-size:12px;box-shadow:0 8px 24px #0002';warning.textContent='Setup required: add your Supabase project URL and anon key in config.js, then run supabase/schema.sql.';document.body.appendChild(warning);}
})();
